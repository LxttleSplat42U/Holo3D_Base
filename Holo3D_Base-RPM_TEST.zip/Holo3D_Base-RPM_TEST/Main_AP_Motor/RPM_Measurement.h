#pragma once
extern const int RPM_SENSOR; // Pin for Hall-effect sensor
extern volatile int nbladePasses; // Used to count the number of blade passes in the interrupt
extern volatile bool bladePassed;
extern volatile bool RPMMeasurementEnabled;
extern const int tRPMDebounceTime;
extern volatile int tRPMInterrupt;
extern hw_timer_t *RPMTimer; 
extern volatile float sumRPM ;
extern volatile float avgRPM;
extern const int RPMTimerPrescaler;
extern const int RPMTimerCount;
extern const int RPMTimerFreq ;
extern volatile int avgRPMCount;

void IRAM_ATTR INT_bladePassed();
void setupRPMMeasurement();
void IRAM_ATTR RPMTimerCalculate(); // Timer used to calculate rpm at precise intervals
void setupRPMTimer();
void enableRPMMeasurement();
void disableRPMMeasurement();
void MeasureRPM();


