# Holo3D_Base
Main Fan Base ESP32 (C6)
