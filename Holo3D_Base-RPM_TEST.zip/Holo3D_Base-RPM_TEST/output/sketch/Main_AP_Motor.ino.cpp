#line 1 "E:\\Projects\\Holo3D_Base\\Main_AP_Motor\\Main_AP_Motor.ino"
#include <Arduino.h>

#include <WiFi.h> //Used to enable WiFi functionality
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <Arduino_JSON.h>
#include "driver/pulse_cnt.h" //For PCNT
#include "esp_err.h"        //  ensures ESP_ERROR_CHECK is defined otherwise an error occurs for some reason

const int FAN_ID = 1; //Set fan ID


//Pin definitions
uint8_t SpeedSensorPin = 1;

//Speed RPM [Position Sensor]
#define SPEED_SENSOR_PIN 1      // Speed Sensor pin number
#define SAMPLE_INTERVAL_US 1000  // 1 ms = 1000 Hz sampling
const int LOW_TH  = 3100;  // ADC level if no blade passed
const int HIGH_TH = 3120;  // ADC level if blade passed

volatile bool bladePassed = false;
volatile int nBladePasses = 0; //Count number of times the blade has passed

hw_timer_t * TIM0; //Setup hardware timer for accurate and precise timing
int currFanSpeed = 0; //rpm of the fan currently


//Motor Control
const int motorPWM = 8;

//PWM Settings
const int freq = 8000; //Frequency [Hz]
const int resolution = 8; //bits

//User command variables
uint8_t msgSpeed = 0; //Fan Speed 0 - 100


const int Monitor_LED = D13;
bool Monitor_LED_State;
int tblink = 0; 
int tReport = 0;
bool Client_Connected = false;

//WiFi Name and Password
const char* ssid = "Holo3D"; 
AsyncWebServer server(80); //Create a server on port 80
IPAddress staticIP(192, 168, 4, 1); // IP address of the ESP32 
IPAddress gateway(192, 168, 4, 1);  // Same as local_IP for AP 
IPAddress subnet(255, 255, 255, 0); // Subnet mask

//Setup WebSocket
AsyncWebSocket ws("/ws"); //Create a WebSocket object

// put function declarations here:
void SetupInterrupts();

void initWiFiAP(); //Initialize WiFi
void initWebSocket(); //Initialize WebSocket
void LED_Blink(); //Used to check if board is reponsive/active by monitoriung the built in D13 LED flashing
void onWebEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len); //WebSocket Event
void setFanSpeed(uint8_t speed);

void handleBladeInterrupt();
void handleTIM0();

#line 78 "E:\\Projects\\Holo3D_Base\\Main_AP_Motor\\Main_AP_Motor.ino"
void setup();
#line 105 "E:\\Projects\\Holo3D_Base\\Main_AP_Motor\\Main_AP_Motor.ino"
void loop();
#line 68 "E:\\Projects\\Holo3D_Base\\Main_AP_Motor\\Main_AP_Motor.ino"
void SetupInterrupts(){


  //Timer
  TIM0 = timerBegin(25600); //3125 Hz timer (Timer_number, prescaler, upcount?)
  timerAttachInterrupt(TIM0, handleTIM0); //Timer, function to call
  timerAlarm(TIM0, 3125, true, 0); //Timer, ARR, ARR_Enabled?, number of times? (0 = infinite)
}


void setup() {
  //PWM & Motor Control Setup
  pinMode(motorPWM, OUTPUT);  //Ensure Motor is OFF
  digitalWrite(motorPWM, LOW);
  ledcAttach(motorPWM, freq, resolution);

  //Enable Timer and Interrupts
  SetupInterrupts();  

  // put your setup code here, to run once:
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
  request->send(200, "text/html", "<!DOCTYPE html><html><body><h2>ESP32 WebSocket</h2><script>const socket = new WebSocket('ws://' + location.hostname + '/ws'); socket.onopen = () => { console.log('Connected'); socket.send('Hi from browser'); };</script></body></html>");

});

  Serial.begin(115200);
  initWiFiAP();
  initWebSocket();

  //Set initial Built-in LED state
  pinMode(Monitor_LED, OUTPUT);
  digitalWrite(Monitor_LED, LOW);
  Monitor_LED_State = false;

  server.begin();
}

void loop() {
  // put your main code here, to run repeatedly:
  // if (Client_Connected){
  //   if (millis() - tReport > 2000) {
  //     tReport = millis();
  //     ws.textAll("RPM" + String( analogRead(SpeedSensorPin)) + "---" + String(currFanSpeed));
  //   }
  // }

  
  
}

// put function definitions here:
void initWiFiAP(){
//Create WiFi AP
  WiFi.softAPConfig(staticIP, gateway, subnet); //Set static IP, gateway and subnet mask
  WiFi.softAP(ssid); //add password parameter if needed
  IPAddress IP = WiFi.softAPIP(); //Get the IP address of the AP
}

void initWebSocket(){
  ws.onEvent(onWebEvent); //Attach the WebSocket event handler
  server.addHandler(&ws); //Add the WebSocket handler to the server
}

void LED_Blink(){
    Monitor_LED_State = !Monitor_LED_State;
    digitalWrite(Monitor_LED, Monitor_LED_State ? HIGH : LOW);
}

void onWebEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) {
  //Handle WebSocket events here
  if (type == WS_EVT_CONNECT) {
    Serial.println("WebSocket client connected");
    Client_Connected = true;
    ws.textAll("Connected");
  } else if (type == WS_EVT_DISCONNECT) {
    Serial.println("WebSocket client disconnected");
    //User Disconnected
    setFanSpeed(0); //Switch off fan immediately if user disconnected!

    Client_Connected = false;
  } else if (type == WS_EVT_DATA) {
    Serial.printf("WebSocket data received: %.*s\n", len, data);
    // Process incoming data
    String msg = "";
    for (size_t i = 0; i < len; i++) {
      msg += (char) data[i];
    }

    ws.textAll(msg); //Forward message to all clients

    if (msg.startsWith("MOTOR_SPEED:") ){
      String msgValue = msg.substring(strlen("MOTOR_SPEED:"));
      msgSpeed = msgValue.toInt(); //0 - 255
      setFanSpeed(msgSpeed);
    } 
    
    
    
  }
}

void setFanSpeed(uint8_t speed){
  ledcWrite(motorPWM, speed); //Duty Cycle (0-255)
}

//Function to calculate the current fan speed at consistent/known intervals
void handleTIM0(){

  int sensorValue = analogRead(SPEED_SENSOR_PIN);

  if (!bladePassed && sensorValue >= HIGH_TH){
    bladePassed = true;
    nBladePasses++;
  } else if (bladePassed && sensorValue <= LOW_TH){
    bladePassed = false;
  }

  if (!Client_Connected){ //Check to see if timer initialised correctly
  LED_Blink();
  }

  currFanSpeed = nBladePasses;        //get the fan speed (divide by time 1s)
//nBladePasses = 0; //Reset counter
}
